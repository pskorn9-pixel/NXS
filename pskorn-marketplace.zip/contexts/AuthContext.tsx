import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { trpc } from "@/lib/trpc";

export type AppUser = {
  id: number;
  username: string;
  role: "customer" | "admin";
  coins: number;
};

type AuthContextType = {
  user: AppUser | null;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | null>(null);

const AUTH_KEY = "pskorn_user";

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const loginMutation = trpc.auth.login.useMutation();
  const registerMutation = trpc.auth.register.useMutation();
  const profileQuery = trpc.auth.getProfile.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user?.id, refetchInterval: 30000 },
  );

  useEffect(() => {
    loadUser();
  }, []);

  useEffect(() => {
    if (profileQuery.data && user) {
      const updated = {
        ...user,
        coins: profileQuery.data.coins,
        role: profileQuery.data.role,
      };
      setUser(updated);
      AsyncStorage.setItem(AUTH_KEY, JSON.stringify(updated));
    }
  }, [profileQuery.data]);

  async function loadUser() {
    try {
      const stored = await AsyncStorage.getItem(AUTH_KEY);
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch (e) {
      console.warn("Failed to load user:", e);
    } finally {
      setIsLoading(false);
    }
  }

  async function login(username: string, password: string) {
    const result = await loginMutation.mutateAsync({ username, password });
    const userData: AppUser = {
      id: result.id,
      username: result.username,
      role: result.role,
      coins: result.coins,
    };
    setUser(userData);
    await AsyncStorage.setItem(AUTH_KEY, JSON.stringify(userData));
  }

  async function register(username: string, password: string) {
    const result = await registerMutation.mutateAsync({ username, password });
    const userData: AppUser = {
      id: result.id,
      username: result.username,
      role: result.role,
      coins: result.coins,
    };
    setUser(userData);
    await AsyncStorage.setItem(AUTH_KEY, JSON.stringify(userData));
  }

  async function logout() {
    setUser(null);
    await AsyncStorage.removeItem(AUTH_KEY);
  }

  async function refreshUser() {
    if (!user) return;
    // Trigger profile refetch via profileQuery invalidation
    await profileQuery.refetch();
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAppAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAppAuth must be used within AuthProvider");
  return ctx;
}
