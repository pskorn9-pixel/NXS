import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Alert,
  Linking,
} from "react-native";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAppAuth } from "@/contexts/AuthContext";
import { trpc } from "@/lib/trpc";

export default function ProfileScreen() {
  const { user, logout, refreshUser } = useAppAuth();
  const [refreshing, setRefreshing] = useState(false);

  const { data: orders } = trpc.orders.listByUser.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user },
  );
  const { data: topups } = trpc.topups.listByUser.useQuery(
    { userId: user?.id ?? 0 },
    { enabled: !!user },
  );

  const completedOrders = (orders || []).filter((o) => o.status === "completed");
  const approvedTopups = (topups || []).filter((t) => t.status === "approved");
  const totalSpent = completedOrders.reduce((sum, o) => sum + o.price, 0);

  async function handleRefresh() {
    setRefreshing(true);
    await refreshUser();
    setRefreshing(false);
  }

  async function handleLogout() {
    Alert.alert("ออกจากระบบ", "ต้องการออกจากระบบ?", [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "ออกจากระบบ",
        style: "destructive",
        onPress: async () => {
          await logout();
          router.replace("/");
        },
      },
    ]);
  }

  if (!user) return null;

  const isAdmin = user.role === "admin";

  return (
    <ScreenContainer containerClassName="bg-navy">
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{user.username[0]?.toUpperCase()}</Text>
            </View>
            {isAdmin && (
              <View style={styles.adminCrown}>
                <Text style={styles.adminCrownText}>👑</Text>
              </View>
            )}
          </View>
          <Text style={styles.username}>{user.username}</Text>
          <View style={styles.roleBadge}>
            <Text style={styles.roleText}>
              {isAdmin ? "👑 ผู้ดูแลระบบ" : "👤 ลูกค้า"}
            </Text>
          </View>
        </View>

        {/* Coin Balance */}
        <View style={styles.coinCard}>
          <Text style={styles.coinCardLabel}>ยอดเหรียญคงเหลือ</Text>
          <View style={styles.coinRow}>
            <Text style={styles.coinEmoji}>🪙</Text>
            <Text style={styles.coinBalance}>{user.coins.toLocaleString()}</Text>
          </View>
          <Pressable
            style={({ pressed }) => [styles.refreshBtn, pressed && { opacity: 0.7 }]}
            onPress={handleRefresh}
          >
            <Text style={styles.refreshBtnText}>
              {refreshing ? "กำลังอัพเดท..." : "↻ อัพเดทยอด"}
            </Text>
          </Pressable>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{completedOrders.length}</Text>
            <Text style={styles.statLabel}>สั่งซื้อแล้ว</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{totalSpent.toLocaleString()}</Text>
            <Text style={styles.statLabel}>🪙 ใช้ไปทั้งหมด</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{approvedTopups.length}</Text>
            <Text style={styles.statLabel}>ครั้งที่เติม</Text>
          </View>
        </View>

        {/* Menu */}
        <View style={styles.menuSection}>
          <Text style={styles.menuSectionTitle}>บัญชีของฉัน</Text>

          <MenuItem
            icon="🛒"
            label="ประวัติการสั่งซื้อ"
            onPress={() => router.push("/(tabs)/orders" as any)}
          />
          <MenuItem
            icon="💰"
            label="เติมเงิน"
            onPress={() => router.push("/(tabs)/topup" as any)}
          />
          {isAdmin && (
            <MenuItem
              icon="🛡"
              label="แผงผู้ดูแล"
              onPress={() => router.push("/(tabs)/admin" as any)}
            />
          )}
        </View>

        <View style={styles.menuSection}>
          <Text style={styles.menuSectionTitle}>ทั่วไป</Text>
          <MenuItem
            icon="🌐"
            label="เว็บไซต์ผู้ดูแล (Backend)"
            onPress={() => {
              Alert.alert(
                "เชื่อมต่อเว็บ Backend",
                "เปิดลิงก์เว็บ Backend สำหรับจัดการระบบ?",
                [
                  { text: "ยกเลิก", style: "cancel" },
                  {
                    text: "เปิด",
                    onPress: () => Linking.openURL("https://pskorn-marketplace.manus.space"),
                  },
                ],
              );
            }}
          />
          <MenuItem
            icon="ℹ️"
            label="เกี่ยวกับ App"
            onPress={() => {
              Alert.alert(
                "PSKORN999 Marketplace",
                "v1.0.0\nแพลตฟอร์มซื้อขายไฟล์ รูปภาพ วีดีโอ\nพัฒนาโดย PSKORN999",
              );
            }}
          />
        </View>

        {/* Logout */}
        <Pressable
          style={({ pressed }) => [styles.logoutBtn, pressed && styles.logoutBtnPressed]}
          onPress={handleLogout}
        >
          <Text style={styles.logoutBtnText}>🚪 ออกจากระบบ</Text>
        </Pressable>

        <Text style={styles.versionText}>PSKORN999 Marketplace v1.0.0</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

function MenuItem({
  icon,
  label,
  onPress,
}: {
  icon: string;
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      style={({ pressed }) => [styles.menuItem, pressed && styles.menuItemPressed]}
      onPress={onPress}
    >
      <Text style={styles.menuItemIcon}>{icon}</Text>
      <Text style={styles.menuItemLabel}>{label}</Text>
      <Text style={styles.menuItemArrow}>›</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  profileHeader: {
    alignItems: "center",
    paddingTop: 24,
    paddingBottom: 20,
    gap: 10,
  },
  avatarContainer: {
    position: "relative",
  },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: "#1A1A35",
    borderWidth: 3,
    borderColor: "#FFD700",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#FFD700",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 15,
    elevation: 8,
  },
  avatarText: {
    fontSize: 36,
    fontWeight: "800",
    color: "#FFD700",
  },
  adminCrown: {
    position: "absolute",
    top: -8,
    right: -8,
    backgroundColor: "#0A0A1A",
    borderRadius: 12,
    padding: 2,
  },
  adminCrownText: {
    fontSize: 20,
  },
  username: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
    letterSpacing: 1,
  },
  roleBadge: {
    backgroundColor: "#2A2000",
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 5,
  },
  roleText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#FFD700",
  },
  coinCard: {
    marginHorizontal: 16,
    backgroundColor: "#1A1A35",
    borderRadius: 20,
    padding: 20,
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#FFD700",
    gap: 8,
    marginBottom: 16,
    shadowColor: "#FFD700",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 4,
  },
  coinCardLabel: {
    fontSize: 13,
    color: "#9BA1C0",
    letterSpacing: 0.5,
  },
  coinRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  coinEmoji: {
    fontSize: 28,
  },
  coinBalance: {
    fontSize: 36,
    fontWeight: "900",
    color: "#FFD700",
  },
  refreshBtn: {
    backgroundColor: "#2A2A4A",
    paddingHorizontal: 16,
    paddingVertical: 7,
    borderRadius: 20,
  },
  refreshBtnText: {
    fontSize: 13,
    color: "#9BA1C0",
    fontWeight: "600",
  },
  statsRow: {
    flexDirection: "row",
    marginHorizontal: 16,
    backgroundColor: "#1A1A35",
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#2A2A4A",
  },
  statItem: {
    flex: 1,
    alignItems: "center",
    gap: 4,
  },
  statValue: {
    fontSize: 20,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  statLabel: {
    fontSize: 11,
    color: "#9BA1C0",
    textAlign: "center",
  },
  statDivider: {
    width: 1,
    backgroundColor: "#2A2A4A",
    marginVertical: 4,
  },
  menuSection: {
    marginHorizontal: 16,
    marginBottom: 16,
    gap: 4,
  },
  menuSectionTitle: {
    fontSize: 12,
    fontWeight: "700",
    color: "#9BA1C0",
    letterSpacing: 1,
    marginBottom: 6,
    marginLeft: 4,
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 16,
    gap: 12,
    borderWidth: 1,
    borderColor: "#2A2A4A",
  },
  menuItemPressed: {
    opacity: 0.7,
    transform: [{ scale: 0.99 }],
  },
  menuItemIcon: {
    fontSize: 20,
    width: 28,
    textAlign: "center",
  },
  menuItemLabel: {
    flex: 1,
    fontSize: 15,
    fontWeight: "500",
    color: "#FFFFFF",
  },
  menuItemArrow: {
    fontSize: 20,
    color: "#4A4A6A",
    fontWeight: "300",
  },
  logoutBtn: {
    marginHorizontal: 16,
    backgroundColor: "#EF444422",
    borderWidth: 1,
    borderColor: "#EF4444",
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: "center",
    marginBottom: 12,
  },
  logoutBtnPressed: {
    opacity: 0.7,
    transform: [{ scale: 0.98 }],
  },
  logoutBtnText: {
    fontSize: 16,
    fontWeight: "700",
    color: "#EF4444",
  },
  versionText: {
    textAlign: "center",
    fontSize: 12,
    color: "#2A2A4A",
    marginBottom: 8,
  },
});
