import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  ActivityIndicator,
  RefreshControl,
  Alert,
  ScrollView,
  TextInput,
  Image,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system/legacy";
import { ScreenContainer } from "@/components/screen-container";
import { useAppAuth } from "@/contexts/AuthContext";
import { trpc } from "@/lib/trpc";

type AdminTab = "stats" | "topups" | "products" | "users" | "qr";

const ADMIN_TABS: { key: AdminTab; label: string; icon: string }[] = [
  { key: "stats", label: "ภาพรวม", icon: "📊" },
  { key: "topups", label: "เติมเงิน", icon: "💰" },
  { key: "products", label: "สินค้า", icon: "📦" },
  { key: "users", label: "ผู้ใช้", icon: "👥" },
  { key: "qr", label: "QR Code", icon: "📲" },
];

// ===== Stats Tab =====
function StatsTab({ adminId }: { adminId: number }) {
  const { data: stats, isLoading } = trpc.admin.stats.useQuery({ adminId });

  if (isLoading) return <ActivityIndicator color="#FFD700" style={{ marginTop: 40 }} />;

  const items = [
    { label: "ผู้ใช้ทั้งหมด", value: stats?.totalUsers || 0, icon: "👥", color: "#3B82F6" },
    { label: "สินค้าทั้งหมด", value: stats?.totalProducts || 0, icon: "📦", color: "#8B5CF6" },
    { label: "คำสั่งซื้อ", value: stats?.totalOrders || 0, icon: "🛒", color: "#22C55E" },
    { label: "รอเติมเงิน", value: stats?.pendingTopups || 0, icon: "⏳", color: "#F59E0B" },
    { label: "รายได้รวม (เหรียญ)", value: stats?.totalRevenue || 0, icon: "🪙", color: "#FFD700" },
  ];

  return (
    <View style={styles.statsGrid}>
      {items.map((item, i) => (
        <View key={i} style={[styles.statCard, { borderColor: item.color + "44" }]}>
          <Text style={styles.statIcon}>{item.icon}</Text>
          <Text style={[styles.statValue, { color: item.color }]}>
            {item.value.toLocaleString()}
          </Text>
          <Text style={styles.statLabel}>{item.label}</Text>
        </View>
      ))}
    </View>
  );
}

// ===== Topups Tab =====
function TopupsTab({ adminId }: { adminId: number }) {
  const [refreshing, setRefreshing] = useState(false);
  const { data: topups, isLoading, refetch } = trpc.topups.listPending.useQuery();
  const approveMutation = trpc.topups.approve.useMutation();
  const rejectMutation = trpc.topups.reject.useMutation();

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  async function handleApprove(topupId: number) {
    Alert.alert("ยืนยัน", "อนุมัติการเติมเงินนี้?", [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "อนุมัติ",
        style: "default",
        onPress: async () => {
          try {
            await approveMutation.mutateAsync({ topupId, adminId });
            await refetch();
            Alert.alert("สำเร็จ", "อนุมัติการเติมเงินแล้ว");
          } catch (e: any) {
            Alert.alert("เกิดข้อผิดพลาด", e?.message);
          }
        },
      },
    ]);
  }

  async function handleReject(topupId: number) {
    Alert.alert("ยืนยัน", "ปฏิเสธการเติมเงินนี้?", [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "ปฏิเสธ",
        style: "destructive",
        onPress: async () => {
          try {
            await rejectMutation.mutateAsync({ topupId, adminId });
            await refetch();
          } catch (e: any) {
            Alert.alert("เกิดข้อผิดพลาด", e?.message);
          }
        },
      },
    ]);
  }

  if (isLoading) return <ActivityIndicator color="#FFD700" style={{ marginTop: 40 }} />;

  return (
    <FlatList
      data={topups || []}
      keyExtractor={(item) => item.id.toString()}
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#FFD700" />
      }
      ListEmptyComponent={
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>✅</Text>
          <Text style={styles.emptyText}>ไม่มีรายการรอตรวจสอบ</Text>
        </View>
      }
      renderItem={({ item }) => (
        <View style={styles.topupCard}>
          <View style={styles.topupInfo}>
            <Text style={styles.topupUser}>👤 User #{item.userId}</Text>
            <Text style={styles.topupAmount}>
              {parseFloat(item.amountThb).toFixed(2)} บาท → 🪙 {item.coinsToAdd.toLocaleString()}
            </Text>
            <Text style={styles.topupDate}>
              {new Date(item.createdAt).toLocaleDateString("th-TH")}
            </Text>
            {item.slipUrl && (
              <Image source={{ uri: item.slipUrl }} style={styles.slipThumb} resizeMode="cover" />
            )}
          </View>
          <View style={styles.topupActions}>
            <Pressable
              style={styles.approveBtn}
              onPress={() => handleApprove(item.id)}
            >
              <Text style={styles.approveBtnText}>✓</Text>
            </Pressable>
            <Pressable
              style={styles.rejectBtn}
              onPress={() => handleReject(item.id)}
            >
              <Text style={styles.rejectBtnText}>✕</Text>
            </Pressable>
          </View>
        </View>
      )}
    />
  );
}

// ===== Products Tab =====
function ProductsTab({ adminId }: { adminId: number }) {
  const [refreshing, setRefreshing] = useState(false);
  const { data: products, isLoading, refetch } = trpc.products.listAll.useQuery();
  const deleteMutation = trpc.products.delete.useMutation();
  const updateMutation = trpc.products.update.useMutation();

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  async function handleDelete(id: number, title: string) {
    Alert.alert("ลบสินค้า", `ต้องการลบ "${title}"?`, [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "ลบ",
        style: "destructive",
        onPress: async () => {
          try {
            await deleteMutation.mutateAsync({ id, userId: adminId });
            await refetch();
          } catch (e: any) {
            Alert.alert("เกิดข้อผิดพลาด", e?.message);
          }
        },
      },
    ]);
  }

  async function handleToggleStatus(id: number, currentStatus: string) {
    const newStatus = currentStatus === "active" ? "inactive" : "active";
    try {
      await updateMutation.mutateAsync({ id, userId: adminId, status: newStatus as any });
      await refetch();
    } catch (e: any) {
      Alert.alert("เกิดข้อผิดพลาด", e?.message);
    }
  }

  if (isLoading) return <ActivityIndicator color="#FFD700" style={{ marginTop: 40 }} />;

  return (
    <FlatList
      data={products || []}
      keyExtractor={(item) => item.id.toString()}
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#FFD700" />
      }
      ListEmptyComponent={
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📦</Text>
          <Text style={styles.emptyText}>ยังไม่มีสินค้า</Text>
        </View>
      }
      renderItem={({ item }) => (
        <View style={styles.productCard}>
          <View style={styles.productInfo}>
            <Text style={styles.productTitle} numberOfLines={1}>{item.title}</Text>
            <Text style={styles.productMeta}>
              🪙 {item.price} · ⬇ {item.downloadCount}
            </Text>
            <View
              style={[
                styles.statusDot,
                { backgroundColor: item.status === "active" ? "#22C55E" : "#EF4444" },
              ]}
            >
              <Text style={styles.statusDotText}>
                {item.status === "active" ? "เปิดขาย" : "ปิดขาย"}
              </Text>
            </View>
          </View>
          <View style={styles.productActions}>
            <Pressable
              style={styles.toggleBtn}
              onPress={() => handleToggleStatus(item.id, item.status)}
            >
              <Text style={styles.toggleBtnText}>
                {item.status === "active" ? "ปิด" : "เปิด"}
              </Text>
            </Pressable>
            <Pressable
              style={styles.deleteBtn}
              onPress={() => handleDelete(item.id, item.title)}
            >
              <Text style={styles.deleteBtnText}>🗑</Text>
            </Pressable>
          </View>
        </View>
      )}
    />
  );
}

// ===== Users Tab =====
function UsersTab({ adminId }: { adminId: number }) {
  const { data: users, isLoading } = trpc.admin.users.useQuery({ adminId });

  if (isLoading) return <ActivityIndicator color="#FFD700" style={{ marginTop: 40 }} />;

  return (
    <FlatList
      data={users || []}
      keyExtractor={(item) => item.id.toString()}
      contentContainerStyle={styles.listContent}
      showsVerticalScrollIndicator={false}
      renderItem={({ item }) => (
        <View style={styles.userCard}>
          <View style={styles.userAvatar}>
            <Text style={styles.userAvatarText}>{item.username[0]?.toUpperCase()}</Text>
          </View>
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{item.username}</Text>
            <Text style={styles.userRole}>
              {item.role === "admin" ? "👑 ผู้ดูแล" : "👤 ลูกค้า"}
            </Text>
          </View>
          <View style={styles.userRight}>
            <Text style={styles.userCoins}>🪙 {item.coins.toLocaleString()}</Text>
            <Text style={styles.userDate}>
              {new Date(item.createdAt).toLocaleDateString("th-TH")}
            </Text>
          </View>
        </View>
      )}
    />
  );
}

// ===== QR Code Tab =====
function QrTab({ adminId }: { adminId: number }) {
  const [bankName, setBankName] = useState("");
  const [accountName, setAccountName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [qrImage, setQrImage] = useState<string | null>(null);
  const [qrBase64, setQrBase64] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const { data: qrCodes, isLoading, refetch } = trpc.bankQr.listAll.useQuery();
  const createMutation = trpc.bankQr.create.useMutation();
  const updateMutation = trpc.bankQr.update.useMutation();
  const deleteMutation = trpc.bankQr.delete.useMutation();

  async function pickQrImage() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.9,
    });
    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      setQrImage(uri);
      const base64 = await FileSystem.readAsStringAsync(uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      setQrBase64(base64);
    }
  }

  async function handleCreate() {
    if (!bankName || !accountName || !qrBase64) {
      Alert.alert("แจ้งเตือน", "กรุณากรอกข้อมูลให้ครบและเลือกรูป QR Code");
      return;
    }
    setAdding(true);
    try {
      await createMutation.mutateAsync({
        adminId,
        bankName,
        accountName,
        accountNumber,
        qrImageBase64: qrBase64,
      });
      setBankName("");
      setAccountName("");
      setAccountNumber("");
      setQrImage(null);
      setQrBase64(null);
      setShowForm(false);
      await refetch();
      Alert.alert("สำเร็จ", "เพิ่ม QR Code แล้ว");
    } catch (e: any) {
      Alert.alert("เกิดข้อผิดพลาด", e?.message);
    } finally {
      setAdding(false);
    }
  }

  async function handleToggleActive(id: number, isActive: boolean) {
    try {
      await updateMutation.mutateAsync({ id, adminId, isActive: !isActive });
      await refetch();
    } catch (e: any) {
      Alert.alert("เกิดข้อผิดพลาด", e?.message);
    }
  }

  async function handleDelete(id: number) {
    Alert.alert("ลบ QR Code", "ต้องการลบ QR Code นี้?", [
      { text: "ยกเลิก", style: "cancel" },
      {
        text: "ลบ",
        style: "destructive",
        onPress: async () => {
          try {
            await deleteMutation.mutateAsync({ id, adminId });
            await refetch();
          } catch (e: any) {
            Alert.alert("เกิดข้อผิดพลาด", e?.message);
          }
        },
      },
    ]);
  }

  return (
    <ScrollView contentContainerStyle={styles.listContent} showsVerticalScrollIndicator={false}>
      <Pressable style={styles.addQrBtn} onPress={() => setShowForm(!showForm)}>
        <Text style={styles.addQrBtnText}>{showForm ? "✕ ยกเลิก" : "+ เพิ่ม QR Code"}</Text>
      </Pressable>

      {showForm && (
        <View style={styles.qrForm}>
          <Text style={styles.qrFormTitle}>เพิ่ม QR Code ธนาคาร</Text>

          <TextInput
            style={styles.qrInput}
            placeholder="ชื่อธนาคาร (เช่น ธนาคารกสิกรไทย)"
            placeholderTextColor="#4A4A6A"
            value={bankName}
            onChangeText={setBankName}
          />
          <TextInput
            style={styles.qrInput}
            placeholder="ชื่อบัญชี"
            placeholderTextColor="#4A4A6A"
            value={accountName}
            onChangeText={setAccountName}
          />
          <TextInput
            style={styles.qrInput}
            placeholder="เลขที่บัญชี (ไม่บังคับ)"
            placeholderTextColor="#4A4A6A"
            value={accountNumber}
            onChangeText={setAccountNumber}
            keyboardType="numeric"
          />

          <Pressable style={styles.qrImagePicker} onPress={pickQrImage}>
            {qrImage ? (
              <Image source={{ uri: qrImage }} style={styles.qrPreview} resizeMode="contain" />
            ) : (
              <View style={styles.qrPickerPlaceholder}>
                <Text style={styles.qrPickerIcon}>📲</Text>
                <Text style={styles.qrPickerText}>เลือกรูป QR Code</Text>
              </View>
            )}
          </Pressable>

          <Pressable
            style={[styles.saveQrBtn, adding && { opacity: 0.6 }]}
            onPress={handleCreate}
            disabled={adding}
          >
            {adding ? (
              <ActivityIndicator color="#0A0A1A" />
            ) : (
              <Text style={styles.saveQrBtnText}>บันทึก QR Code</Text>
            )}
          </Pressable>
        </View>
      )}

      {isLoading ? (
        <ActivityIndicator color="#FFD700" style={{ marginTop: 20 }} />
      ) : (
        (qrCodes || []).map((qr) => (
          <View key={qr.id} style={styles.qrCard}>
            <Image source={{ uri: qr.qrImageUrl }} style={styles.qrCardImage} resizeMode="contain" />
            <View style={styles.qrCardInfo}>
              <Text style={styles.qrBankName}>{qr.bankName}</Text>
              <Text style={styles.qrAccountName}>{qr.accountName}</Text>
              {qr.accountNumber && (
                <Text style={styles.qrAccountNumber}>{qr.accountNumber}</Text>
              )}
              <View style={styles.qrCardActions}>
                <Pressable
                  style={[styles.qrToggleBtn, { backgroundColor: qr.isActive ? "#22C55E22" : "#EF444422" }]}
                  onPress={() => handleToggleActive(qr.id, qr.isActive)}
                >
                  <Text style={{ color: qr.isActive ? "#22C55E" : "#EF4444", fontSize: 12, fontWeight: "700" }}>
                    {qr.isActive ? "เปิดใช้" : "ปิดใช้"}
                  </Text>
                </Pressable>
                <Pressable style={styles.qrDeleteBtn} onPress={() => handleDelete(qr.id)}>
                  <Text style={styles.qrDeleteBtnText}>🗑</Text>
                </Pressable>
              </View>
            </View>
          </View>
        ))
      )}
    </ScrollView>
  );
}

// ===== Main Admin Screen =====
export default function AdminScreen() {
  const { user } = useAppAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>("stats");

  if (!user || user.role !== "admin") {
    return (
      <ScreenContainer containerClassName="bg-navy">
        <View style={styles.noAccessContainer}>
          <Text style={styles.noAccessIcon}>🔒</Text>
          <Text style={styles.noAccessText}>คุณไม่มีสิทธิ์เข้าถึงหน้านี้</Text>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-navy">
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🛡 ผู้ดูแลระบบ</Text>
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>👑 Admin</Text>
        </View>
      </View>

      {/* Tabs */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.tabScrollContent}
        style={styles.tabScroll}
      >
        {ADMIN_TABS.map((tab) => (
          <Pressable
            key={tab.key}
            style={[styles.adminTab, activeTab === tab.key && styles.adminTabActive]}
            onPress={() => setActiveTab(tab.key)}
          >
            <Text style={styles.adminTabIcon}>{tab.icon}</Text>
            <Text style={[styles.adminTabLabel, activeTab === tab.key && styles.adminTabLabelActive]}>
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Content */}
      <View style={styles.content}>
        {activeTab === "stats" && <StatsTab adminId={user.id} />}
        {activeTab === "topups" && <TopupsTab adminId={user.id} />}
        {activeTab === "products" && <ProductsTab adminId={user.id} />}
        {activeTab === "users" && <UsersTab adminId={user.id} />}
        {activeTab === "qr" && <QrTab adminId={user.id} />}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 8,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  adminBadge: {
    backgroundColor: "#2A2000",
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 5,
  },
  adminBadgeText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#FFD700",
  },
  tabScroll: {
    flexGrow: 0,
    paddingBottom: 8,
  },
  tabScrollContent: {
    paddingHorizontal: 16,
    gap: 8,
  },
  adminTab: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#2A2A4A",
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    gap: 5,
  },
  adminTabActive: {
    backgroundColor: "#2A2000",
    borderColor: "#FFD700",
  },
  adminTabIcon: {
    fontSize: 14,
  },
  adminTabLabel: {
    fontSize: 13,
    color: "#9BA1C0",
    fontWeight: "600",
  },
  adminTabLabelActive: {
    color: "#FFD700",
  },
  content: {
    flex: 1,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 16,
    paddingTop: 12,
    gap: 10,
  },
  statCard: {
    width: "47%",
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 16,
    alignItems: "center",
    gap: 6,
    borderWidth: 1,
  },
  statIcon: {
    fontSize: 28,
  },
  statValue: {
    fontSize: 22,
    fontWeight: "800",
  },
  statLabel: {
    fontSize: 11,
    color: "#9BA1C0",
    textAlign: "center",
  },
  listContent: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 20,
    gap: 10,
  },
  topupCard: {
    flexDirection: "row",
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "#2A2A4A",
    gap: 12,
    alignItems: "center",
  },
  topupInfo: {
    flex: 1,
    gap: 4,
  },
  topupUser: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  topupAmount: {
    fontSize: 13,
    color: "#FFD700",
    fontWeight: "600",
  },
  topupDate: {
    fontSize: 11,
    color: "#9BA1C0",
  },
  slipThumb: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginTop: 6,
  },
  topupActions: {
    gap: 8,
  },
  approveBtn: {
    backgroundColor: "#22C55E",
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  approveBtnText: {
    fontSize: 18,
    color: "#FFFFFF",
    fontWeight: "800",
  },
  rejectBtn: {
    backgroundColor: "#EF4444",
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  rejectBtnText: {
    fontSize: 18,
    color: "#FFFFFF",
    fontWeight: "800",
  },
  productCard: {
    flexDirection: "row",
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "#2A2A4A",
    gap: 12,
    alignItems: "center",
  },
  productInfo: {
    flex: 1,
    gap: 4,
  },
  productTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  productMeta: {
    fontSize: 12,
    color: "#9BA1C0",
  },
  statusDot: {
    alignSelf: "flex-start",
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  statusDotText: {
    fontSize: 11,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  productActions: {
    flexDirection: "row",
    gap: 8,
    alignItems: "center",
  },
  toggleBtn: {
    backgroundColor: "#2A2A4A",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
  },
  toggleBtnText: {
    fontSize: 12,
    color: "#FFD700",
    fontWeight: "700",
  },
  deleteBtn: {
    backgroundColor: "#EF444422",
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 10,
  },
  deleteBtnText: {
    fontSize: 16,
  },
  userCard: {
    flexDirection: "row",
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "#2A2A4A",
    gap: 12,
    alignItems: "center",
  },
  userAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "#2A2A4A",
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
    borderColor: "#FFD700",
  },
  userAvatarText: {
    fontSize: 18,
    fontWeight: "800",
    color: "#FFD700",
  },
  userInfo: {
    flex: 1,
    gap: 3,
  },
  userName: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  userRole: {
    fontSize: 12,
    color: "#9BA1C0",
  },
  userRight: {
    alignItems: "flex-end",
    gap: 3,
  },
  userCoins: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFD700",
  },
  userDate: {
    fontSize: 11,
    color: "#9BA1C0",
  },
  addQrBtn: {
    backgroundColor: "#FFD700",
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: "center",
    marginBottom: 12,
  },
  addQrBtnText: {
    fontSize: 15,
    fontWeight: "800",
    color: "#0A0A1A",
  },
  qrForm: {
    backgroundColor: "#1A1A35",
    borderRadius: 16,
    padding: 16,
    gap: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#2A2A4A",
  },
  qrFormTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFD700",
  },
  qrInput: {
    backgroundColor: "#12122A",
    borderWidth: 1,
    borderColor: "#2A2A4A",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: "#FFFFFF",
  },
  qrImagePicker: {
    backgroundColor: "#12122A",
    borderWidth: 2,
    borderColor: "#2A2A4A",
    borderStyle: "dashed",
    borderRadius: 12,
    height: 140,
    overflow: "hidden",
  },
  qrPreview: {
    width: "100%",
    height: "100%",
  },
  qrPickerPlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  qrPickerIcon: {
    fontSize: 32,
  },
  qrPickerText: {
    fontSize: 13,
    color: "#9BA1C0",
  },
  saveQrBtn: {
    backgroundColor: "#FFD700",
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
  },
  saveQrBtnText: {
    fontSize: 15,
    fontWeight: "800",
    color: "#0A0A1A",
  },
  qrCard: {
    flexDirection: "row",
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 12,
    borderWidth: 1,
    borderColor: "#2A2A4A",
    gap: 12,
    alignItems: "center",
  },
  qrCardImage: {
    width: 80,
    height: 80,
    borderRadius: 10,
    backgroundColor: "#FFFFFF",
  },
  qrCardInfo: {
    flex: 1,
    gap: 3,
  },
  qrBankName: {
    fontSize: 14,
    fontWeight: "800",
    color: "#FFD700",
  },
  qrAccountName: {
    fontSize: 13,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  qrAccountNumber: {
    fontSize: 12,
    color: "#9BA1C0",
  },
  qrCardActions: {
    flexDirection: "row",
    gap: 8,
    marginTop: 6,
  },
  qrToggleBtn: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  qrDeleteBtn: {
    backgroundColor: "#EF444422",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 8,
  },
  qrDeleteBtnText: {
    fontSize: 14,
  },
  emptyContainer: {
    alignItems: "center",
    paddingTop: 60,
    gap: 12,
  },
  emptyIcon: {
    fontSize: 48,
  },
  emptyText: {
    fontSize: 15,
    color: "#9BA1C0",
  },
  noAccessContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
  },
  noAccessIcon: {
    fontSize: 56,
  },
  noAccessText: {
    fontSize: 18,
    color: "#9BA1C0",
    fontWeight: "600",
  },
});
