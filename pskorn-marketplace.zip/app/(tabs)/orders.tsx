import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  ActivityIndicator,
  RefreshControl,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useAppAuth } from "@/contexts/AuthContext";
import { trpc } from "@/lib/trpc";

type TabKey = "orders" | "cancelled" | "topup";

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: "orders", label: "สั่งซื้อ", icon: "🛒" },
  { key: "cancelled", label: "ยกเลิก", icon: "❌" },
  { key: "topup", label: "เติมเงิน", icon: "💰" },
];

function OrderCard({ order, product }: { order: any; product?: any }) {
  const statusColor =
    order.status === "completed"
      ? "#22C55E"
      : order.status === "cancelled"
        ? "#EF4444"
        : "#F59E0B";
  const statusLabel =
    order.status === "completed" ? "สำเร็จ" : order.status === "cancelled" ? "ยกเลิก" : "รอดำเนินการ";
  const fileTypeIcon =
    product?.fileType === "image" ? "🖼" : product?.fileType === "video" ? "🎬" : "📄";

  return (
    <View style={styles.orderCard}>
      <View style={styles.orderIconArea}>
        <Text style={styles.orderIcon}>{fileTypeIcon}</Text>
      </View>
      <View style={styles.orderInfo}>
        <Text style={styles.orderTitle} numberOfLines={1}>
          {product?.title || `สินค้า #${order.productId}`}
        </Text>
        <Text style={styles.orderDate}>
          {new Date(order.createdAt).toLocaleDateString("th-TH", {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>
      </View>
      <View style={styles.orderRight}>
        <Text style={styles.orderPrice}>🪙 {order.price.toLocaleString()}</Text>
        <View style={[styles.statusBadge, { backgroundColor: statusColor + "22" }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>{statusLabel}</Text>
        </View>
      </View>
    </View>
  );
}

function TopupCard({ topup }: { topup: any }) {
  const statusColor =
    topup.status === "approved"
      ? "#22C55E"
      : topup.status === "rejected"
        ? "#EF4444"
        : "#F59E0B";
  const statusLabel =
    topup.status === "approved" ? "อนุมัติแล้ว" : topup.status === "rejected" ? "ปฏิเสธ" : "รอตรวจสอบ";

  return (
    <View style={styles.orderCard}>
      <View style={[styles.orderIconArea, { backgroundColor: "#2A2000" }]}>
        <Text style={styles.orderIcon}>💰</Text>
      </View>
      <View style={styles.orderInfo}>
        <Text style={styles.orderTitle}>เติมเงิน {parseFloat(topup.amountThb).toFixed(2)} บาท</Text>
        <Text style={styles.orderDate}>
          {new Date(topup.createdAt).toLocaleDateString("th-TH", {
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
          })}
        </Text>
        {topup.adminNote && (
          <Text style={styles.adminNote}>หมายเหตุ: {topup.adminNote}</Text>
        )}
      </View>
      <View style={styles.orderRight}>
        <Text style={styles.orderPrice}>🪙 +{topup.coinsToAdd.toLocaleString()}</Text>
        <View style={[styles.statusBadge, { backgroundColor: statusColor + "22" }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>{statusLabel}</Text>
        </View>
      </View>
    </View>
  );
}

export default function OrdersScreen() {
  const { user } = useAppAuth();
  const [activeTab, setActiveTab] = useState<TabKey>("orders");
  const [refreshing, setRefreshing] = useState(false);

  const { data: orders, isLoading: ordersLoading, refetch: refetchOrders } =
    trpc.orders.listByUser.useQuery({ userId: user?.id ?? 0 }, { enabled: !!user });

  const { data: topups, isLoading: topupsLoading, refetch: refetchTopups } =
    trpc.topups.listByUser.useQuery({ userId: user?.id ?? 0 }, { enabled: !!user });

  const { data: allProducts } = trpc.products.listAll.useQuery();

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([refetchOrders(), refetchTopups()]);
    setRefreshing(false);
  }, [refetchOrders, refetchTopups]);

  const completedOrders = (orders || []).filter((o) => o.status === "completed");
  const cancelledOrders = (orders || []).filter((o) => o.status === "cancelled");

  function getProduct(productId: number) {
    return allProducts?.find((p) => p.id === productId);
  }

  const isLoading = ordersLoading || topupsLoading;

  return (
    <ScreenContainer containerClassName="bg-navy">
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>📦 การสั่งซื้อ</Text>
        <View style={styles.coinBadge}>
          <Text style={styles.coinText}>🪙 {(user?.coins || 0).toLocaleString()}</Text>
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabRow}>
        {TABS.map((tab) => (
          <Pressable
            key={tab.key}
            style={[styles.tab, activeTab === tab.key && styles.tabActive]}
            onPress={() => setActiveTab(tab.key)}
          >
            <Text style={styles.tabIcon}>{tab.icon}</Text>
            <Text style={[styles.tabLabel, activeTab === tab.key && styles.tabLabelActive]}>
              {tab.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FFD700" />
        </View>
      ) : activeTab === "topup" ? (
        <FlatList
          data={topups || []}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#FFD700"
              colors={["#FFD700"]}
            />
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyIcon}>💰</Text>
              <Text style={styles.emptyText}>ยังไม่มีประวัติการเติมเงิน</Text>
            </View>
          }
          renderItem={({ item }) => <TopupCard topup={item} />}
        />
      ) : (
        <FlatList
          data={(activeTab === "orders" ? completedOrders : cancelledOrders) as any[]}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#FFD700"
              colors={["#FFD700"]}
            />
          }
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyIcon}>
                {activeTab === "orders" ? "🛒" : activeTab === "cancelled" ? "❌" : "💰"}
              </Text>
              <Text style={styles.emptyText}>
                {activeTab === "orders"
                  ? "ยังไม่มีประวัติการสั่งซื้อ"
                  : activeTab === "cancelled"
                    ? "ไม่มีรายการที่ยกเลิก"
                    : "ยังไม่มีประวัติการเติมเงิน"}
              </Text>
            </View>
          }
          renderItem={({ item }) => (
            <OrderCard order={item} product={getProduct((item as any).productId)} />
          )}
        />
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  coinBadge: {
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  coinText: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFD700",
  },
  tabRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 8,
  },
  tab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#2A2A4A",
    borderRadius: 12,
    paddingVertical: 10,
    gap: 4,
  },
  tabActive: {
    backgroundColor: "#2A2000",
    borderColor: "#FFD700",
  },
  tabIcon: {
    fontSize: 14,
  },
  tabLabel: {
    fontSize: 12,
    color: "#9BA1C0",
    fontWeight: "600",
  },
  tabLabelActive: {
    color: "#FFD700",
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 20,
    gap: 10,
  },
  orderCard: {
    flexDirection: "row",
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 12,
    alignItems: "center",
    gap: 12,
    borderWidth: 1,
    borderColor: "#2A2A4A",
  },
  orderIconArea: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: "#12122A",
    alignItems: "center",
    justifyContent: "center",
  },
  orderIcon: {
    fontSize: 22,
  },
  orderInfo: {
    flex: 1,
    gap: 3,
  },
  orderTitle: {
    fontSize: 14,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  orderDate: {
    fontSize: 11,
    color: "#9BA1C0",
  },
  adminNote: {
    fontSize: 11,
    color: "#F59E0B",
    fontStyle: "italic",
  },
  orderRight: {
    alignItems: "flex-end",
    gap: 4,
  },
  orderPrice: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFD700",
  },
  statusBadge: {
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  statusText: {
    fontSize: 11,
    fontWeight: "600",
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingTop: 80,
    gap: 12,
  },
  emptyIcon: {
    fontSize: 48,
  },
  emptyText: {
    fontSize: 15,
    color: "#9BA1C0",
  },
});
