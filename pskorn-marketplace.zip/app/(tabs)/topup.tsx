import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Pressable,
  ActivityIndicator,
  ScrollView,
  Alert,
  Image,
  Platform,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import * as FileSystem from "expo-file-system/legacy";
import { ScreenContainer } from "@/components/screen-container";
import { useAppAuth } from "@/contexts/AuthContext";
import { trpc } from "@/lib/trpc";

const COIN_RATE = 5; // 5 coins = 1 THB

export default function TopupScreen() {
  const { user, refreshUser } = useAppAuth();
  const [amount, setAmount] = useState("");
  const [slipImage, setSlipImage] = useState<string | null>(null);
  const [slipBase64, setSlipBase64] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [topupId, setTopupId] = useState<number | null>(null);
  const [step, setStep] = useState<"input" | "qr" | "done">("input");

  const { data: qrCodes, isLoading: qrLoading } = trpc.bankQr.listActive.useQuery();
  const createTopupMutation = trpc.topups.create.useMutation();
  const uploadSlipMutation = trpc.topups.uploadSlip.useMutation();

  const coins = amount ? Math.floor(parseFloat(amount) * COIN_RATE) : 0;
  const activeQr = qrCodes?.[0];

  async function handleCreateTopup() {
    const amountNum = parseFloat(amount);
    if (!amount || isNaN(amountNum) || amountNum < 1) {
      Alert.alert("แจ้งเตือน", "กรุณากรอกจำนวนเงินอย่างน้อย 1 บาท");
      return;
    }
    if (!activeQr) {
      Alert.alert("แจ้งเตือน", "ยังไม่มี QR Code สำหรับเติมเงิน กรุณาติดต่อผู้ดูแล");
      return;
    }
    setLoading(true);
    try {
      const result = await createTopupMutation.mutateAsync({
        userId: user!.id,
        amountThb: amountNum,
        bankQrId: activeQr.id,
      });
      setTopupId(result.id);
      setStep("qr");
    } catch (e: any) {
      Alert.alert("เกิดข้อผิดพลาด", e?.message || "กรุณาลองใหม่");
    } finally {
      setLoading(false);
    }
  }

  async function pickSlip() {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.8,
      base64: false,
    });
    if (!result.canceled && result.assets[0]) {
      const uri = result.assets[0].uri;
      setSlipImage(uri);
      // Read as base64
      try {
        const base64 = await FileSystem.readAsStringAsync(uri, {
          encoding: FileSystem.EncodingType.Base64,
        });
        setSlipBase64(base64);
      } catch (e) {
        console.warn("Failed to read slip:", e);
      }
    }
  }

  async function handleUploadSlip() {
    if (!slipBase64 || !topupId) {
      Alert.alert("แจ้งเตือน", "กรุณาเลือกรูปสลิปโอนเงิน");
      return;
    }
    setLoading(true);
    try {
      await uploadSlipMutation.mutateAsync({
        topupId,
        slipBase64,
        mimeType: "image/jpeg",
      });
      setStep("done");
      await refreshUser();
    } catch (e: any) {
      Alert.alert("เกิดข้อผิดพลาด", e?.message || "กรุณาลองใหม่");
    } finally {
      setLoading(false);
    }
  }

  function handleReset() {
    setAmount("");
    setSlipImage(null);
    setSlipBase64(null);
    setTopupId(null);
    setStep("input");
  }

  return (
    <ScreenContainer containerClassName="bg-navy">
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>💰 เติมเงิน</Text>
          <View style={styles.coinBadge}>
            <Text style={styles.coinText}>🪙 {(user?.coins || 0).toLocaleString()}</Text>
          </View>
        </View>

        {/* Rate info */}
        <View style={styles.rateCard}>
          <Text style={styles.rateTitle}>อัตราแลกเปลี่ยน</Text>
          <View style={styles.rateRow}>
            <Text style={styles.rateValue}>1 บาท</Text>
            <Text style={styles.rateArrow}>→</Text>
            <Text style={styles.rateCoins}>🪙 {COIN_RATE} เหรียญ</Text>
          </View>
        </View>

        {step === "input" && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>จำนวนเงินที่ต้องการเติม</Text>

            <View style={styles.amountRow}>
              <TextInput
                style={styles.amountInput}
                placeholder="0.00"
                placeholderTextColor="#4A4A6A"
                value={amount}
                onChangeText={setAmount}
                keyboardType="decimal-pad"
                returnKeyType="done"
              />
              <Text style={styles.amountUnit}>บาท</Text>
            </View>

            {coins > 0 && (
              <View style={styles.coinsPreview}>
                <Text style={styles.coinsPreviewText}>
                  คุณจะได้รับ{" "}
                  <Text style={styles.coinsPreviewAmount}>🪙 {coins.toLocaleString()} เหรียญ</Text>
                </Text>
              </View>
            )}

            <Pressable
              style={({ pressed }) => [
                styles.nextBtn,
                pressed && styles.nextBtnPressed,
                loading && styles.btnDisabled,
              ]}
              onPress={handleCreateTopup}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color="#0A0A1A" />
              ) : (
                <Text style={styles.nextBtnText}>ถัดไป →</Text>
              )}
            </Pressable>
          </View>
        )}

        {step === "qr" && activeQr && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>สแกน QR Code เพื่อโอนเงิน</Text>

            <View style={styles.qrCard}>
              <Text style={styles.bankName}>{activeQr.bankName}</Text>
              <Text style={styles.accountName}>{activeQr.accountName}</Text>
              {activeQr.accountNumber && (
                <Text style={styles.accountNumber}>เลขที่บัญชี: {activeQr.accountNumber}</Text>
              )}
              <Image
                source={{ uri: activeQr.qrImageUrl }}
                style={styles.qrImage}
                resizeMode="contain"
              />
              <View style={styles.amountDisplay}>
                <Text style={styles.amountDisplayLabel}>โอนจำนวน</Text>
                <Text style={styles.amountDisplayValue}>{parseFloat(amount).toFixed(2)} บาท</Text>
              </View>
            </View>

            <Text style={styles.slipTitle}>อัพโหลดสลิปโอนเงิน</Text>

            <Pressable style={styles.slipPicker} onPress={pickSlip}>
              {slipImage ? (
                <Image source={{ uri: slipImage }} style={styles.slipPreview} resizeMode="cover" />
              ) : (
                <View style={styles.slipPlaceholder}>
                  <Text style={styles.slipPlaceholderIcon}>📷</Text>
                  <Text style={styles.slipPlaceholderText}>แตะเพื่อเลือกรูปสลิป</Text>
                </View>
              )}
            </Pressable>

            <Pressable
              style={({ pressed }) => [
                styles.nextBtn,
                pressed && styles.nextBtnPressed,
                (!slipImage || loading) && styles.btnDisabled,
              ]}
              onPress={handleUploadSlip}
              disabled={!slipImage || loading}
            >
              {loading ? (
                <ActivityIndicator color="#0A0A1A" />
              ) : (
                <Text style={styles.nextBtnText}>ส่งหลักฐาน</Text>
              )}
            </Pressable>
          </View>
        )}

        {step === "done" && (
          <View style={styles.doneSection}>
            <Text style={styles.doneIcon}>✅</Text>
            <Text style={styles.doneTitle}>ส่งหลักฐานสำเร็จ!</Text>
            <Text style={styles.doneText}>
              รอผู้ดูแลตรวจสอบและอนุมัติ{"\n"}
              เหรียญจะเข้าบัญชีของคุณหลังได้รับการอนุมัติ
            </Text>
            <View style={styles.doneSummary}>
              <Text style={styles.doneSummaryText}>
                จำนวน: {parseFloat(amount).toFixed(2)} บาท → 🪙 {coins.toLocaleString()} เหรียญ
              </Text>
            </View>
            <Pressable style={styles.nextBtn} onPress={handleReset}>
              <Text style={styles.nextBtnText}>เติมเงินอีกครั้ง</Text>
            </Pressable>
          </View>
        )}

        {qrLoading && (
          <View style={styles.loadingContainer}>
            <ActivityIndicator color="#FFD700" />
          </View>
        )}

        {!qrLoading && !activeQr && step === "input" && (
          <View style={styles.noQrCard}>
            <Text style={styles.noQrIcon}>⚠️</Text>
            <Text style={styles.noQrText}>ยังไม่มีช่องทางการเติมเงิน{"\n"}กรุณาติดต่อผู้ดูแลระบบ</Text>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  coinBadge: {
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  coinText: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFD700",
  },
  rateCard: {
    marginHorizontal: 16,
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "#2A2A4A",
    marginBottom: 20,
  },
  rateTitle: {
    fontSize: 12,
    color: "#9BA1C0",
    marginBottom: 8,
    fontWeight: "600",
    letterSpacing: 0.5,
  },
  rateRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  rateValue: {
    fontSize: 18,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  rateArrow: {
    fontSize: 18,
    color: "#9BA1C0",
  },
  rateCoins: {
    fontSize: 18,
    fontWeight: "800",
    color: "#FFD700",
  },
  section: {
    paddingHorizontal: 16,
    gap: 14,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  amountRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  amountInput: {
    flex: 1,
    backgroundColor: "#1A1A35",
    borderWidth: 1.5,
    borderColor: "#2A2A4A",
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 16,
    fontSize: 24,
    fontWeight: "700",
    color: "#FFFFFF",
    textAlign: "center",
  },
  amountUnit: {
    fontSize: 18,
    fontWeight: "600",
    color: "#9BA1C0",
  },
  coinsPreview: {
    backgroundColor: "#2A2000",
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 12,
    padding: 12,
    alignItems: "center",
  },
  coinsPreviewText: {
    fontSize: 15,
    color: "#FFFFFF",
    fontWeight: "500",
  },
  coinsPreviewAmount: {
    fontSize: 18,
    fontWeight: "800",
    color: "#FFD700",
  },
  nextBtn: {
    backgroundColor: "#FFD700",
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: "center",
    shadowColor: "#FFD700",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 6,
  },
  nextBtnPressed: {
    transform: [{ scale: 0.97 }],
    opacity: 0.9,
  },
  btnDisabled: {
    opacity: 0.5,
  },
  nextBtnText: {
    fontSize: 17,
    fontWeight: "800",
    color: "#0A0A1A",
    letterSpacing: 0.5,
  },
  qrCard: {
    backgroundColor: "#1A1A35",
    borderRadius: 16,
    padding: 20,
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderColor: "#FFD700",
  },
  bankName: {
    fontSize: 18,
    fontWeight: "800",
    color: "#FFD700",
  },
  accountName: {
    fontSize: 15,
    fontWeight: "600",
    color: "#FFFFFF",
  },
  accountNumber: {
    fontSize: 13,
    color: "#9BA1C0",
  },
  qrImage: {
    width: 220,
    height: 220,
    borderRadius: 12,
    marginVertical: 8,
    backgroundColor: "#FFFFFF",
  },
  amountDisplay: {
    backgroundColor: "#2A2000",
    borderRadius: 10,
    paddingHorizontal: 20,
    paddingVertical: 10,
    alignItems: "center",
    gap: 2,
  },
  amountDisplayLabel: {
    fontSize: 12,
    color: "#9BA1C0",
  },
  amountDisplayValue: {
    fontSize: 22,
    fontWeight: "800",
    color: "#FFD700",
  },
  slipTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: "#FFFFFF",
  },
  slipPicker: {
    backgroundColor: "#1A1A35",
    borderWidth: 2,
    borderColor: "#2A2A4A",
    borderStyle: "dashed",
    borderRadius: 16,
    height: 160,
    overflow: "hidden",
  },
  slipPreview: {
    width: "100%",
    height: "100%",
  },
  slipPlaceholder: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  slipPlaceholderIcon: {
    fontSize: 36,
  },
  slipPlaceholderText: {
    fontSize: 14,
    color: "#9BA1C0",
  },
  doneSection: {
    paddingHorizontal: 16,
    alignItems: "center",
    gap: 16,
    paddingTop: 20,
  },
  doneIcon: {
    fontSize: 64,
  },
  doneTitle: {
    fontSize: 24,
    fontWeight: "800",
    color: "#22C55E",
  },
  doneText: {
    fontSize: 14,
    color: "#9BA1C0",
    textAlign: "center",
    lineHeight: 22,
  },
  doneSummary: {
    backgroundColor: "#1A1A35",
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: "#FFD700",
    width: "100%",
    alignItems: "center",
  },
  doneSummaryText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#FFD700",
  },
  loadingContainer: {
    padding: 20,
    alignItems: "center",
  },
  noQrCard: {
    marginHorizontal: 16,
    backgroundColor: "#1A1A35",
    borderRadius: 14,
    padding: 20,
    alignItems: "center",
    gap: 10,
    borderWidth: 1,
    borderColor: "#F59E0B",
  },
  noQrIcon: {
    fontSize: 32,
  },
  noQrText: {
    fontSize: 14,
    color: "#F59E0B",
    textAlign: "center",
    lineHeight: 22,
  },
});
