import React, { useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Pressable,
  TextInput,
  ActivityIndicator,
  RefreshControl,
  Image,
  Dimensions,
} from "react-native";
import { router } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useAppAuth } from "@/contexts/AuthContext";
import { trpc } from "@/lib/trpc";
import { LightningBackground } from "@/components/LightningBackground";
import { IconSymbol } from "@/components/ui/icon-symbol";

const { width } = Dimensions.get("window");
const CARD_WIDTH = (width - 48) / 2;

type FilterType = "all" | "image" | "video" | "file";

const FILTERS: { key: FilterType; label: string; icon: string }[] = [
  { key: "all", label: "ทั้งหมด", icon: "🌟" },
  { key: "image", label: "รูปภาพ", icon: "🖼" },
  { key: "video", label: "วีดีโอ", icon: "🎬" },
  { key: "file", label: "ไฟล์", icon: "📄" },
];

function ProductCard({ item, onPress }: { item: any; onPress: () => void }) {
  const fileTypeIcon = item.fileType === "image" ? "🖼" : item.fileType === "video" ? "🎬" : "📄";
  const fileTypeBg =
    item.fileType === "image"
      ? "#1A3A1A"
      : item.fileType === "video"
        ? "#1A1A3A"
        : "#2A1A1A";

  return (
    <Pressable
      style={({ pressed }) => [styles.card, pressed && styles.cardPressed]}
      onPress={onPress}
    >
      {/* Thumbnail */}
      <View style={[styles.thumbnail, { backgroundColor: fileTypeBg }]}>
        {item.thumbnailUrl ? (
          <Image source={{ uri: item.thumbnailUrl }} style={styles.thumbnailImage} />
        ) : (
          <Text style={styles.thumbnailIcon}>{fileTypeIcon}</Text>
        )}
        <View style={styles.fileTypeBadge}>
          <Text style={styles.fileTypeBadgeText}>{fileTypeIcon}</Text>
        </View>
      </View>

      {/* Info */}
      <View style={styles.cardInfo}>
        <Text style={styles.cardTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <View style={styles.priceRow}>
          <Text style={styles.coinIcon}>🪙</Text>
          <Text style={styles.price}>{item.price.toLocaleString()}</Text>
        </View>
        <Text style={styles.downloads}>⬇ {item.downloadCount}</Text>
      </View>
    </Pressable>
  );
}

export default function HomeScreen() {
  const { user } = useAppAuth();
  const [filter, setFilter] = useState<FilterType>("all");
  const [search, setSearch] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const { data: products, isLoading, refetch } = trpc.products.list.useQuery();

  const filteredProducts = (products || []).filter((p) => {
    const matchFilter = filter === "all" || p.fileType === filter;
    const matchSearch =
      search === "" || p.title.toLowerCase().includes(search.toLowerCase());
    return matchFilter && matchSearch;
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refetch();
    setRefreshing(false);
  }, [refetch]);

  return (
    <ScreenContainer containerClassName="bg-navy">
      <LightningBackground />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Text style={styles.headerTitle}>⚡ PSKORN999</Text>
          <Text style={styles.headerSub}>Marketplace</Text>
        </View>
        <View style={styles.coinBadge}>
          <Text style={styles.coinIcon2}>🪙</Text>
          <Text style={styles.coinAmount}>{(user?.coins || 0).toLocaleString()}</Text>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchContainer}>
        <View style={styles.searchBox}>
          <IconSymbol name="magnifyingglass" size={18} color="#9BA1C0" />
          <TextInput
            style={styles.searchInput}
            placeholder="ค้นหาสินค้า..."
            placeholderTextColor="#4A4A6A"
            value={search}
            onChangeText={setSearch}
          />
          {search !== "" && (
            <Pressable onPress={() => setSearch("")}>
              <IconSymbol name="xmark" size={16} color="#9BA1C0" />
            </Pressable>
          )}
        </View>
        {user?.role === "admin" && (
          <Pressable
            style={styles.addBtn}
            onPress={() => router.push("/admin/post-product" as any)}
          >
            <IconSymbol name="plus.circle.fill" size={28} color="#FFD700" />
          </Pressable>
        )}
      </View>

      {/* Filter chips */}
      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <Pressable
            key={f.key}
            style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
            onPress={() => setFilter(f.key)}
          >
            <Text style={styles.filterIcon}>{f.icon}</Text>
            <Text
              style={[styles.filterLabel, filter === f.key && styles.filterLabelActive]}
            >
              {f.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Products Grid */}
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FFD700" />
          <Text style={styles.loadingText}>กำลังโหลด...</Text>
        </View>
      ) : filteredProducts.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📦</Text>
          <Text style={styles.emptyText}>ยังไม่มีสินค้า</Text>
          {user?.role === "admin" && (
            <Pressable
              style={styles.addFirstBtn}
              onPress={() => router.push("/admin/post-product" as any)}
            >
              <Text style={styles.addFirstBtnText}>+ โพสต์สินค้าแรก</Text>
            </Pressable>
          )}
        </View>
      ) : (
        <FlatList
          data={filteredProducts}
          numColumns={2}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.grid}
          columnWrapperStyle={styles.row}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor="#FFD700"
              colors={["#FFD700"]}
            />
          }
          renderItem={({ item }) => (
            <ProductCard
              item={item}
              onPress={() => router.push(`/product/${item.id}` as any)}
            />
          )}
        />
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 8,
  },
  headerLeft: {},
  headerTitle: {
    fontSize: 20,
    fontWeight: "900",
    color: "#FFD700",
    letterSpacing: 1,
  },
  headerSub: {
    fontSize: 11,
    color: "#9BA1C0",
    letterSpacing: 2,
  },
  coinBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    gap: 4,
  },
  coinIcon2: {
    fontSize: 16,
  },
  coinAmount: {
    fontSize: 15,
    fontWeight: "700",
    color: "#FFD700",
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 8,
    gap: 10,
  },
  searchBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#2A2A4A",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: "#FFFFFF",
  },
  addBtn: {
    padding: 4,
  },
  filterRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 8,
  },
  filterChip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#2A2A4A",
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
    gap: 4,
  },
  filterChipActive: {
    backgroundColor: "#2A2000",
    borderColor: "#FFD700",
  },
  filterIcon: {
    fontSize: 13,
  },
  filterLabel: {
    fontSize: 12,
    color: "#9BA1C0",
    fontWeight: "500",
  },
  filterLabelActive: {
    color: "#FFD700",
    fontWeight: "700",
  },
  loadingContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  loadingText: {
    color: "#9BA1C0",
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  emptyIcon: {
    fontSize: 48,
  },
  emptyText: {
    fontSize: 16,
    color: "#9BA1C0",
  },
  addFirstBtn: {
    backgroundColor: "#FFD700",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 12,
    marginTop: 8,
  },
  addFirstBtnText: {
    color: "#0A0A1A",
    fontWeight: "700",
    fontSize: 14,
  },
  grid: {
    paddingHorizontal: 16,
    paddingBottom: 20,
    gap: 12,
  },
  row: {
    gap: 12,
    justifyContent: "space-between",
  },
  card: {
    width: CARD_WIDTH,
    backgroundColor: "#1A1A35",
    borderRadius: 16,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: "#2A2A4A",
  },
  cardPressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
  thumbnail: {
    width: "100%",
    height: CARD_WIDTH * 0.75,
    alignItems: "center",
    justifyContent: "center",
  },
  thumbnailImage: {
    width: "100%",
    height: "100%",
    resizeMode: "cover",
  },
  thumbnailIcon: {
    fontSize: 36,
  },
  fileTypeBadge: {
    position: "absolute",
    top: 8,
    right: 8,
    backgroundColor: "rgba(0,0,0,0.6)",
    borderRadius: 8,
    padding: 4,
  },
  fileTypeBadgeText: {
    fontSize: 12,
  },
  cardInfo: {
    padding: 10,
    gap: 4,
  },
  cardTitle: {
    fontSize: 13,
    fontWeight: "600",
    color: "#FFFFFF",
    lineHeight: 18,
  },
  priceRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginTop: 2,
  },
  coinIcon: {
    fontSize: 13,
  },
  price: {
    fontSize: 14,
    fontWeight: "800",
    color: "#FFD700",
  },
  downloads: {
    fontSize: 11,
    color: "#9BA1C0",
  },
});
