import { DarkTheme, ThemeProvider } from "@react-navigation/native";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { trpc, createTRPCClient } from "@/lib/trpc";
import { ThemeProvider as AppThemeProvider } from "@/lib/theme-provider";
import { AuthProvider } from "@/contexts/AuthContext";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();
const trpcClient = createTRPCClient();

const AppDarkTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: "#0A0A1A",
    card: "#12122A",
    text: "#FFFFFF",
    border: "#2A2A4A",
    primary: "#FFD700",
    notification: "#FFD700",
  },
};

export default function RootLayout() {
  useEffect(() => {
    SplashScreen.hideAsync();
  }, []);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <trpc.Provider client={trpcClient} queryClient={queryClient}>
        <QueryClientProvider client={queryClient}>
          <AppThemeProvider>
            <AuthProvider>
              <ThemeProvider value={AppDarkTheme}>
                <Stack screenOptions={{ headerShown: false }}>
                  <Stack.Screen name="index" />
                  <Stack.Screen name="login" />
                  <Stack.Screen name="register" />
                  <Stack.Screen name="(tabs)" />
                  <Stack.Screen
                    name="product/[id]"
                    options={{
                      headerShown: true,
                      headerTitle: "รายละเอียดสินค้า",
                      headerStyle: { backgroundColor: "#12122A" },
                      headerTintColor: "#FFD700",
                    }}
                  />
                  <Stack.Screen
                    name="admin/post-product"
                    options={{
                      headerShown: true,
                      headerTitle: "โพสต์สินค้า",
                      headerStyle: { backgroundColor: "#12122A" },
                      headerTintColor: "#FFD700",
                    }}
                  />
                </Stack>
                <StatusBar style="light" backgroundColor="#0A0A1A" />
              </ThemeProvider>
            </AuthProvider>
          </AppThemeProvider>
        </QueryClientProvider>
      </trpc.Provider>
    </GestureHandlerRootView>
  );
}
