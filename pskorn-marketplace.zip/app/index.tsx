import React, { useEffect } from "react";
import { View, Text, StyleSheet, Pressable, ActivityIndicator } from "react-native";
import { router } from "expo-router";
import { useAppAuth } from "@/contexts/AuthContext";
import { LightningBackground } from "@/components/LightningBackground";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withSequence,
  Easing,
} from "react-native-reanimated";

export default function SplashScreen() {
  const { user, isLoading } = useAppAuth();
  const logoScale = useSharedValue(0.8);
  const logoOpacity = useSharedValue(0);
  const buttonOpacity = useSharedValue(0);
  const glowOpacity = useSharedValue(0.5);

  useEffect(() => {
    logoOpacity.value = withTiming(1, { duration: 800 });
    logoScale.value = withTiming(1, { duration: 800, easing: Easing.out(Easing.back(1.2)) });
    buttonOpacity.value = withTiming(1, { duration: 800 });
    glowOpacity.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1500 }),
        withTiming(0.4, { duration: 1500 }),
      ),
      -1,
      true,
    );
  }, []);

  useEffect(() => {
    if (!isLoading && user) {
      router.replace("/(tabs)");
    }
  }, [isLoading, user]);

  const logoStyle = useAnimatedStyle(() => ({
    opacity: logoOpacity.value,
    transform: [{ scale: logoScale.value }],
  }));

  const buttonStyle = useAnimatedStyle(() => ({
    opacity: buttonOpacity.value,
  }));

  const glowStyle = useAnimatedStyle(() => ({
    opacity: glowOpacity.value,
  }));

  if (isLoading) {
    return (
      <View style={styles.container}>
        <LightningBackground />
        <ActivityIndicator size="large" color="#FFD700" />
      </View>
    );
  }

  if (user) return null;

  return (
    <View style={styles.container}>
      <LightningBackground />

      {/* Glow effect */}
      <Animated.View style={[styles.glow, glowStyle]} />

      {/* Logo area */}
      <Animated.View style={[styles.logoContainer, logoStyle]}>
        <View style={styles.logoCircle}>
          <Text style={styles.logoEmoji}>⚡</Text>
        </View>
        <Text style={styles.appName}>PSKORN999</Text>
        <Text style={styles.appSubtitle}>Marketplace</Text>
        <Text style={styles.tagline}>ซื้อขายไฟล์ รูปภาพ วีดีโอ</Text>
      </Animated.View>

      {/* Enter button */}
      <Animated.View style={[styles.buttonContainer, buttonStyle]}>
        <Pressable
          style={({ pressed }) => [
            styles.enterButton,
            pressed && styles.enterButtonPressed,
          ]}
          onPress={() => router.push("/login" as any)}>
          <Text style={styles.enterButtonText}>⚡ เข้าสู่ระบบ</Text>
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.registerButton,
            pressed && styles.registerButtonPressed,
          ]}
          onPress={() => router.push("/register" as any)}>
          <Text style={styles.registerButtonText}>สมัครสมาชิก</Text>
        </Pressable>
      </Animated.View>

      <Text style={styles.version}>v1.0.0</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0A0A1A",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 32,
  },
  glow: {
    position: "absolute",
    width: 300,
    height: 300,
    borderRadius: 150,
    backgroundColor: "#FFD700",
    opacity: 0.08,
    top: "30%",
    alignSelf: "center",
  },
  logoContainer: {
    alignItems: "center",
    marginBottom: 60,
  },
  logoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: "#1A1A35",
    borderWidth: 2,
    borderColor: "#FFD700",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 20,
    shadowColor: "#FFD700",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 10,
  },
  logoEmoji: {
    fontSize: 48,
  },
  appName: {
    fontSize: 32,
    fontWeight: "900",
    color: "#FFD700",
    letterSpacing: 3,
    textShadowColor: "#FFD700",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  appSubtitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#FFFFFF",
    letterSpacing: 4,
    marginTop: 4,
  },
  tagline: {
    fontSize: 13,
    color: "#9BA1C0",
    marginTop: 12,
    letterSpacing: 1,
  },
  buttonContainer: {
    width: "100%",
    gap: 12,
  },
  enterButton: {
    backgroundColor: "#FFD700",
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: "center",
    shadowColor: "#FFD700",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  enterButtonPressed: {
    transform: [{ scale: 0.97 }],
    opacity: 0.9,
  },
  enterButtonText: {
    fontSize: 18,
    fontWeight: "800",
    color: "#0A0A1A",
    letterSpacing: 1,
  },
  registerButton: {
    backgroundColor: "transparent",
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: "center",
    borderWidth: 1.5,
    borderColor: "#FFD700",
  },
  registerButtonPressed: {
    transform: [{ scale: 0.97 }],
    opacity: 0.8,
  },
  registerButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFD700",
    letterSpacing: 1,
  },
  version: {
    position: "absolute",
    bottom: 40,
    color: "#2A2A4A",
    fontSize: 12,
  },
});
