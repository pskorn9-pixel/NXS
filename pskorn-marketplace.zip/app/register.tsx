import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Pressable,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from "react-native";
import { router } from "expo-router";
import { useAppAuth } from "@/contexts/AuthContext";
import { LightningBackground } from "@/components/LightningBackground";

export default function RegisterScreen() {
  const { register } = useAppAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  function getPasswordRole(pw: string): string {
    if (pw.length >= 30) return "👑 ผู้ดูแลระบบ";
    if (pw.length >= 6) return "👤 ลูกค้า";
    return "";
  }

  async function handleRegister() {
    if (username.trim().length < 6) {
      Alert.alert("แจ้งเตือน", "ชื่อผู้ใช้ต้องมีอย่างน้อย 6 ตัวอักษร");
      return;
    }
    if (password.length < 6) {
      Alert.alert("แจ้งเตือน", "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร");
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert("แจ้งเตือน", "รหัสผ่านไม่ตรงกัน");
      return;
    }
    setLoading(true);
    try {
      await register(username.trim(), password);
      router.replace("/(tabs)");
    } catch (e: any) {
      Alert.alert("สมัครสมาชิกไม่สำเร็จ", e?.message || "เกิดข้อผิดพลาด กรุณาลองใหม่");
    } finally {
      setLoading(false);
    }
  }

  const roleLabel = getPasswordRole(password);

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <LightningBackground />
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backText}>← กลับ</Text>
        </Pressable>

        <View style={styles.logoArea}>
          <Text style={styles.logoEmoji}>⚡</Text>
          <Text style={styles.title}>สมัครสมาชิก</Text>
          <Text style={styles.subtitle}>PSKORN999 Marketplace</Text>
        </View>

        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>ชื่อผู้ใช้ (อย่างน้อย 6 ตัวอักษร)</Text>
            <TextInput
              style={[
                styles.input,
                username.length > 0 && username.trim().length < 6 && styles.inputError,
              ]}
              placeholder="กรอกชื่อผู้ใช้"
              placeholderTextColor="#4A4A6A"
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              autoCorrect={false}
              returnKeyType="next"
            />
            {username.length > 0 && username.trim().length < 6 && (
              <Text style={styles.errorText}>ต้องมีอย่างน้อย 6 ตัวอักษร</Text>
            )}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>รหัสผ่าน (อย่างน้อย 6 ตัวอักษร)</Text>
            <View style={styles.passwordRow}>
              <TextInput
                style={[styles.input, { flex: 1 }]}
                placeholder="กรอกรหัสผ่าน"
                placeholderTextColor="#4A4A6A"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword}
                returnKeyType="next"
              />
              <Pressable
                style={styles.eyeBtn}
                onPress={() => setShowPassword(!showPassword)}
              >
                <Text style={styles.eyeText}>{showPassword ? "🙈" : "👁"}</Text>
              </Pressable>
            </View>
            {roleLabel !== "" && (
              <View style={styles.roleBadge}>
                <Text style={styles.roleText}>{roleLabel}</Text>
                <Text style={styles.roleHint}>
                  {password.length >= 30
                    ? "รหัสผ่าน 30+ ตัว = สิทธิ์ผู้ดูแลระบบ"
                    : "รหัสผ่าน 6-29 ตัว = สิทธิ์ลูกค้า"}
                </Text>
              </View>
            )}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>ยืนยันรหัสผ่าน</Text>
            <TextInput
              style={[
                styles.input,
                confirmPassword.length > 0 &&
                  confirmPassword !== password &&
                  styles.inputError,
              ]}
              placeholder="กรอกรหัสผ่านอีกครั้ง"
              placeholderTextColor="#4A4A6A"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry={!showPassword}
              returnKeyType="done"
              onSubmitEditing={handleRegister}
            />
            {confirmPassword.length > 0 && confirmPassword !== password && (
              <Text style={styles.errorText}>รหัสผ่านไม่ตรงกัน</Text>
            )}
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.registerBtn,
              pressed && styles.registerBtnPressed,
              loading && styles.registerBtnDisabled,
            ]}
            onPress={handleRegister}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#0A0A1A" />
            ) : (
              <Text style={styles.registerBtnText}>⚡ สมัครสมาชิก</Text>
            )}
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.loginBtn,
              pressed && styles.loginBtnPressed,
            ]}
            onPress={() => router.push("/login" as any)}
          >
            <Text style={styles.loginBtnText}>มีบัญชีแล้ว? เข้าสู่ระบบ</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0A0A1A",
  },
  scroll: {
    flexGrow: 1,
    paddingHorizontal: 28,
    paddingTop: 60,
    paddingBottom: 40,
  },
  backBtn: {
    alignSelf: "flex-start",
    marginBottom: 24,
    padding: 4,
  },
  backText: {
    color: "#FFD700",
    fontSize: 16,
    fontWeight: "600",
  },
  logoArea: {
    alignItems: "center",
    marginBottom: 36,
  },
  logoEmoji: {
    fontSize: 44,
    marginBottom: 10,
  },
  title: {
    fontSize: 26,
    fontWeight: "800",
    color: "#FFD700",
    letterSpacing: 1,
  },
  subtitle: {
    fontSize: 13,
    color: "#9BA1C0",
    marginTop: 4,
    letterSpacing: 1,
  },
  form: {
    gap: 16,
  },
  inputGroup: {
    gap: 8,
  },
  label: {
    fontSize: 13,
    fontWeight: "600",
    color: "#FFD700",
    letterSpacing: 0.5,
  },
  input: {
    backgroundColor: "#1A1A35",
    borderWidth: 1.5,
    borderColor: "#2A2A4A",
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    color: "#FFFFFF",
  },
  inputError: {
    borderColor: "#EF4444",
  },
  errorText: {
    fontSize: 12,
    color: "#EF4444",
    marginTop: -4,
  },
  passwordRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  eyeBtn: {
    backgroundColor: "#1A1A35",
    borderWidth: 1.5,
    borderColor: "#2A2A4A",
    borderRadius: 14,
    padding: 14,
  },
  eyeText: {
    fontSize: 18,
  },
  roleBadge: {
    backgroundColor: "#1A1A35",
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 10,
    padding: 10,
    gap: 2,
  },
  roleText: {
    fontSize: 14,
    fontWeight: "700",
    color: "#FFD700",
  },
  roleHint: {
    fontSize: 11,
    color: "#9BA1C0",
  },
  registerBtn: {
    backgroundColor: "#FFD700",
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: "center",
    marginTop: 8,
    shadowColor: "#FFD700",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  registerBtnPressed: {
    transform: [{ scale: 0.97 }],
    opacity: 0.9,
  },
  registerBtnDisabled: {
    opacity: 0.6,
  },
  registerBtnText: {
    fontSize: 18,
    fontWeight: "800",
    color: "#0A0A1A",
    letterSpacing: 1,
  },
  loginBtn: {
    backgroundColor: "transparent",
    paddingVertical: 14,
    borderRadius: 16,
    alignItems: "center",
    borderWidth: 1.5,
    borderColor: "#FFD700",
  },
  loginBtnPressed: {
    transform: [{ scale: 0.97 }],
    opacity: 0.8,
  },
  loginBtnText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#FFD700",
  },
});
