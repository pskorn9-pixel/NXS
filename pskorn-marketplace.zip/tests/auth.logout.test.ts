import { describe, expect, it } from "vitest";

// This app uses custom username/password auth, not Manus OAuth.
// The logout test is not applicable.
describe.skip("auth.logout", () => {
  it("skipped - using custom auth", () => {
    expect(true).toBe(true);
  });
});
