# PSKORN999 Marketplace - Design Plan

## Brand & Theme
- **Primary Color**: Gold (#FFD700) / Dark Gold (#B8860B)
- **Accent**: Electric Yellow (#FFEC00)
- **Background**: Deep Dark Navy (#0A0A1A) with animated lightning bolt particles
- **Surface**: Dark Card (#12122A)
- **Text**: White (#FFFFFF) / Light Gray (#E0E0E0)
- **Success**: Green (#22C55E)
- **Error**: Red (#EF4444)
- **Lightning Animation**: Floating gold/yellow lightning bolt SVGs that drift/pulse across background

## User Roles
1. **Customer** (username ≥6 chars, password ≥6 chars) - browse, buy, top-up
2. **Admin** (username any, password ≥30 chars) - manage all, post products, approve orders
   - Admin credentials: PSKORN999 / 13052005PS (hardcoded admin)

## Screen List

### Auth Screens (before login)
1. **SplashScreen** - App logo + animated lightning background, "เข้าสู่ระบบ" button
2. **LoginScreen** - Username + Password fields, Login button, Register link
3. **RegisterScreen** - Username (≥6), Password (≥6), Confirm Password, Register button

### Main Tabs (after login) - 5 tabs
1. **HomeTab** - Product feed (images, videos, files for sale)
2. **OrdersTab** - Order history, cancel history, top-up history
3. **TopUpTab** - Coin top-up with QR code payment (5 coins = 1 THB)
4. **AdminTab** - Admin panel (only visible to admin role)
5. **ProfileTab** - User profile, coin balance, settings

## Screen Details

### Tab 1: Home (หน้าหลัก)
- Header: App logo + search bar + coin balance badge
- Product grid/list: cards showing image/video/file
- Each card: thumbnail, title, price (coins), seller name, type badge
- Video preview: auto-play 5-10 seconds when scrolling past (muted)
- Filter chips: All / รูปภาพ / วีดีโอ / ไฟล์
- FAB for admin: + Post Product button

### Tab 2: Orders (การสั่งซื้อ)
- Tabs: ประวัติสั่งซื้อ / ยกเลิก / เติมเงิน
- Order card: product thumbnail, title, price, date, status badge
- Top-up history: amount, coins received, date, status

### Tab 3: Top-Up (เติมเงิน)
- Coin balance display (large, gold)
- Exchange rate: 5 coins = 1 บาท
- Amount input (THB) → shows coins to receive
- QR Code display (admin-managed bank QR)
- Bank name display
- Upload slip button
- Admin approval status

### Tab 4: Admin (ผู้ดูแล) - Admin only
- Dashboard: total users, orders, revenue
- Manage Products: list, add, edit, delete
- Manage Orders: approve/reject
- Manage Top-ups: approve/reject with slip review
- Manage QR Codes: add/edit bank QR codes
- User management

### Tab 5: Profile (โปรไฟล์)
- Avatar + username
- Coin balance
- Account info
- Order summary stats
- Settings: change password, theme
- Logout button

## Key User Flows

### Purchase Flow
User taps product → Product Detail screen → "ซื้อ" button → Confirm purchase modal → Deduct coins → Download/view content

### Top-Up Flow
User opens Top-Up tab → Enter THB amount → See QR code → Transfer money → Upload slip → Wait for admin approval → Coins credited

### Admin Post Product Flow
Admin taps + FAB → Upload file (image/video/PDF/any) → Set title, description, price → Submit → Product appears in feed

### Admin Approve Top-Up
Admin opens Admin tab → Top-up requests → View slip → Approve/Reject → User notified

## Layout
- Portrait orientation, one-handed usage
- Bottom tab bar with gold active indicator
- Cards with rounded corners (16px)
- Glassmorphism effect on cards
- Gold gradient headers
