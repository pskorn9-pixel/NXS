import {
  int,
  mysqlTable,
  text,
  timestamp,
  varchar,
  mysqlEnum,
  decimal,
  boolean,
} from "drizzle-orm/mysql-core";

// ===== Manus OAuth Users (required by core framework - DO NOT REMOVE) =====
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: text("loginMethod"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ===== App Users (custom username/password auth) =====
export const appUsers = mysqlTable("app_users", {
  id: int("id").autoincrement().primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  password: varchar("password", { length: 255 }).notNull(),
  role: mysqlEnum("role", ["customer", "admin"]).default("customer").notNull(),
  coins: int("coins").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ===== Products (images, videos, files for sale) =====
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  sellerId: int("sellerId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  price: int("price").notNull(), // in coins
  fileType: mysqlEnum("fileType", ["image", "video", "file"]).notNull(),
  fileUrl: text("fileUrl").notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  fileName: varchar("fileName", { length: 255 }),
  fileSize: int("fileSize"), // bytes
  videoDuration: int("videoDuration"), // seconds
  status: mysqlEnum("status", ["active", "inactive"]).default("active").notNull(),
  downloadCount: int("downloadCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ===== Orders =====
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  buyerId: int("buyerId").notNull(),
  productId: int("productId").notNull(),
  price: int("price").notNull(), // coins paid
  status: mysqlEnum("status", ["completed", "cancelled", "pending"]).default("completed").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

// ===== Top-up requests =====
export const topups = mysqlTable("topups", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  amountThb: decimal("amountThb", { precision: 10, scale: 2 }).notNull(),
  coinsToAdd: int("coinsToAdd").notNull(),
  slipUrl: text("slipUrl"),
  bankQrId: int("bankQrId"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  adminNote: text("adminNote"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// ===== Bank QR Codes (managed by admin) =====
export const bankQrCodes = mysqlTable("bank_qr_codes", {
  id: int("id").autoincrement().primaryKey(),
  bankName: varchar("bankName", { length: 100 }).notNull(),
  accountName: varchar("accountName", { length: 255 }).notNull(),
  accountNumber: varchar("accountNumber", { length: 50 }),
  qrImageUrl: text("qrImageUrl").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

// Export types
export type AppUser = typeof appUsers.$inferSelect;
export type InsertAppUser = typeof appUsers.$inferInsert;
export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;
export type Topup = typeof topups.$inferSelect;
export type InsertTopup = typeof topups.$inferInsert;
export type BankQrCode = typeof bankQrCodes.$inferSelect;
export type InsertBankQrCode = typeof bankQrCodes.$inferInsert;
