import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  appUsers,
  InsertAppUser,
  AppUser,
  products,
  InsertProduct,
  Product,
  orders,
  InsertOrder,
  Order,
  topups,
  InsertTopup,
  Topup,
  bankQrCodes,
  InsertBankQrCode,
  BankQrCode,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ===== Manus OAuth Users (required by core framework) =====
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ===== App Users (custom auth) =====
export async function getAppUserByUsername(username: string): Promise<AppUser | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(appUsers).where(eq(appUsers.username, username)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAppUserById(id: number): Promise<AppUser | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(appUsers).where(eq(appUsers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createAppUser(data: InsertAppUser): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(appUsers).values(data);
  return (result as any)[0]?.insertId ?? 0;
}

export async function updateAppUserCoins(userId: number, coins: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(appUsers).set({ coins }).where(eq(appUsers.id, userId));
}

export async function getAllAppUsers(): Promise<AppUser[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(appUsers).orderBy(desc(appUsers.createdAt));
}

// ===== Products =====
export async function getActiveProducts(): Promise<Product[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(products)
    .where(eq(products.status, "active"))
    .orderBy(desc(products.createdAt));
}

export async function getProductById(id: number): Promise<Product | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createProduct(data: InsertProduct): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(products).values(data);
  return (result as any)[0]?.insertId ?? 0;
}

export async function updateProduct(id: number, data: Partial<InsertProduct>): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(products).where(eq(products.id, id));
}

export async function getAllProducts(): Promise<Product[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(products).orderBy(desc(products.createdAt));
}

// ===== Orders =====
export async function createOrder(data: InsertOrder): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orders).values(data);
  return (result as any)[0]?.insertId ?? 0;
}

export async function getOrdersByBuyer(buyerId: number): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(orders)
    .where(eq(orders.buyerId, buyerId))
    .orderBy(desc(orders.createdAt));
}

export async function getAllOrders(): Promise<Order[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function cancelOrder(orderId: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(orders).set({ status: "cancelled" }).where(eq(orders.id, orderId));
}

// ===== Topups =====
export async function createTopup(data: InsertTopup): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(topups).values(data);
  return (result as any)[0]?.insertId ?? 0;
}

export async function getTopupsByUser(userId: number): Promise<Topup[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(topups)
    .where(eq(topups.userId, userId))
    .orderBy(desc(topups.createdAt));
}

export async function getAllTopups(): Promise<Topup[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(topups).orderBy(desc(topups.createdAt));
}

export async function getPendingTopups(): Promise<Topup[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(topups)
    .where(eq(topups.status, "pending"))
    .orderBy(desc(topups.createdAt));
}

export async function updateTopupStatus(
  id: number,
  status: "approved" | "rejected",
  adminNote?: string,
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(topups)
    .set({ status, adminNote: adminNote ?? null })
    .where(eq(topups.id, id));
}

export async function updateTopupSlip(id: number, slipUrl: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(topups).set({ slipUrl }).where(eq(topups.id, id));
}

// ===== Bank QR Codes =====
export async function getActiveBankQrCodes(): Promise<BankQrCode[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(bankQrCodes)
    .where(eq(bankQrCodes.isActive, true))
    .orderBy(desc(bankQrCodes.createdAt));
}

export async function getAllBankQrCodes(): Promise<BankQrCode[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(bankQrCodes).orderBy(desc(bankQrCodes.createdAt));
}

export async function createBankQrCode(data: InsertBankQrCode): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(bankQrCodes).values(data);
  return (result as any)[0]?.insertId ?? 0;
}

export async function updateBankQrCode(
  id: number,
  data: Partial<InsertBankQrCode>,
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(bankQrCodes).set(data).where(eq(bankQrCodes.id, id));
}

export async function deleteBankQrCode(id: number): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(bankQrCodes).where(eq(bankQrCodes.id, id));
}
