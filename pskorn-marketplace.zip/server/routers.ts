import { z } from "zod";
import { router, protectedProcedure, publicProcedure } from "./_core/trpc";
import * as db from "./db";
import { storagePut } from "./storage";

async function uploadFile(buffer: Buffer, fileName: string, mimeType: string): Promise<string> {
  const result = await storagePut(`uploads/${fileName}`, buffer, mimeType);
  return result.url;
}

// Helper to determine role from password length
function determineRole(password: string): "customer" | "admin" {
  return password.length >= 30 ? "admin" : "customer";
}

export const appRouter = router({
  // ===== Auth =====
  auth: router({
    login: publicProcedure
      .input(
        z.object({
          username: z.string().min(1),
          password: z.string().min(1),
        }),
      )
      .mutation(async ({ input }) => {
        const user = await db.getAppUserByUsername(input.username);
        if (!user) {
          throw new Error("ไม่พบชื่อผู้ใช้นี้");
        }
        if (user.password !== input.password) {
          throw new Error("รหัสผ่านไม่ถูกต้อง");
        }
        return {
          id: user.id,
          username: user.username,
          role: user.role,
          coins: user.coins,
        };
      }),

    register: publicProcedure
      .input(
        z.object({
          username: z.string().min(6, "ชื่อต้องมีอย่างน้อย 6 ตัวอักษร"),
          password: z.string().min(6, "รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร"),
        }),
      )
      .mutation(async ({ input }) => {
        const existing = await db.getAppUserByUsername(input.username);
        if (existing) {
          throw new Error("ชื่อผู้ใช้นี้ถูกใช้งานแล้ว");
        }
        const role = determineRole(input.password);
        const id = await db.createAppUser({
          username: input.username,
          password: input.password,
          role,
          coins: 0,
        });
        return { id, username: input.username, role, coins: 0 };
      }),

    getProfile: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        const user = await db.getAppUserById(input.userId);
        if (!user) throw new Error("ไม่พบผู้ใช้");
        return {
          id: user.id,
          username: user.username,
          role: user.role,
          coins: user.coins,
          createdAt: user.createdAt,
        };
      }),
  }),

  // ===== Products =====
  products: router({
    list: publicProcedure.query(async () => {
      return db.getActiveProducts();
    }),

    listAll: publicProcedure.query(async () => {
      return db.getAllProducts();
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getProductById(input.id);
      }),

    create: publicProcedure
      .input(
        z.object({
          userId: z.number(),
          title: z.string().min(1),
          description: z.string().optional(),
          price: z.number().min(0),
          fileType: z.enum(["image", "video", "file"]),
          fileUrl: z.string(),
          thumbnailUrl: z.string().optional(),
          fileName: z.string().optional(),
          fileSize: z.number().optional(),
          videoDuration: z.number().optional(),
        }),
      )
      .mutation(async ({ input }) => {
        const user = await db.getAppUserById(input.userId);
        if (!user || user.role !== "admin") {
          throw new Error("ไม่มีสิทธิ์โพสต์สินค้า");
        }
        const id = await db.createProduct({
          sellerId: input.userId,
          title: input.title,
          description: input.description,
          price: input.price,
          fileType: input.fileType,
          fileUrl: input.fileUrl,
          thumbnailUrl: input.thumbnailUrl,
          fileName: input.fileName,
          fileSize: input.fileSize,
          videoDuration: input.videoDuration,
          status: "active",
          downloadCount: 0,
        });
        return { id };
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          userId: z.number(),
          title: z.string().optional(),
          description: z.string().optional(),
          price: z.number().optional(),
          status: z.enum(["active", "inactive"]).optional(),
        }),
      )
      .mutation(async ({ input }) => {
        const user = await db.getAppUserById(input.userId);
        if (!user || user.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        const { id, userId, ...data } = input;
        await db.updateProduct(id, data);
        return { success: true };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number(), userId: z.number() }))
      .mutation(async ({ input }) => {
        const user = await db.getAppUserById(input.userId);
        if (!user || user.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        await db.deleteProduct(input.id);
        return { success: true };
      }),
  }),

  // ===== Orders =====
  orders: router({
    create: publicProcedure
      .input(
        z.object({
          userId: z.number(),
          productId: z.number(),
        }),
      )
      .mutation(async ({ input }) => {
        const user = await db.getAppUserById(input.userId);
        if (!user) throw new Error("ไม่พบผู้ใช้");
        const product = await db.getProductById(input.productId);
        if (!product) throw new Error("ไม่พบสินค้า");
        if (product.status !== "active") throw new Error("สินค้านี้ไม่พร้อมขาย");
        if (user.coins < product.price) throw new Error("เหรียญไม่เพียงพอ");
        const newCoins = user.coins - product.price;
        await db.updateAppUserCoins(input.userId, newCoins);
        const orderId = await db.createOrder({
          buyerId: input.userId,
          productId: input.productId,
          price: product.price,
          status: "completed",
        });
        await db.updateProduct(input.productId, {
          downloadCount: product.downloadCount + 1,
        });
        return { orderId, newCoins };
      }),

    listByUser: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return db.getOrdersByBuyer(input.userId);
      }),

    listAll: publicProcedure.query(async () => {
      return db.getAllOrders();
    }),

    cancel: publicProcedure
      .input(z.object({ orderId: z.number(), userId: z.number() }))
      .mutation(async ({ input }) => {
        await db.cancelOrder(input.orderId);
        return { success: true };
      }),
  }),

  // ===== Top-ups =====
  topups: router({
    create: publicProcedure
      .input(
        z.object({
          userId: z.number(),
          amountThb: z.number().min(1),
          bankQrId: z.number().optional(),
        }),
      )
      .mutation(async ({ input }) => {
        const coinsToAdd = Math.floor(input.amountThb * 5);
        const id = await db.createTopup({
          userId: input.userId,
          amountThb: input.amountThb.toString(),
          coinsToAdd,
          bankQrId: input.bankQrId,
          status: "pending",
        });
        return { id, coinsToAdd };
      }),

    uploadSlip: publicProcedure
      .input(
        z.object({
          topupId: z.number(),
          slipBase64: z.string(),
          mimeType: z.string().default("image/jpeg"),
        }),
      )
      .mutation(async ({ input }) => {
        const buffer = Buffer.from(input.slipBase64, "base64");
        const ext = input.mimeType.split("/")[1] || "jpg";
        const fileName = `slip_${input.topupId}_${Date.now()}.${ext}`;
        const url = await uploadFile(buffer, fileName, input.mimeType);
        await db.updateTopupSlip(input.topupId, url);
        return { slipUrl: url };
      }),

    listByUser: publicProcedure
      .input(z.object({ userId: z.number() }))
      .query(async ({ input }) => {
        return db.getTopupsByUser(input.userId);
      }),

    listAll: publicProcedure.query(async () => {
      return db.getAllTopups();
    }),

    listPending: publicProcedure.query(async () => {
      return db.getPendingTopups();
    }),

    approve: publicProcedure
      .input(
        z.object({
          topupId: z.number(),
          adminId: z.number(),
          adminNote: z.string().optional(),
        }),
      )
      .mutation(async ({ input }) => {
        const admin = await db.getAppUserById(input.adminId);
        if (!admin || admin.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        const topup = await (async () => {
          const all = await db.getAllTopups();
          return all.find((t) => t.id === input.topupId);
        })();
        if (!topup) throw new Error("ไม่พบรายการเติมเงิน");
        if (topup.status !== "pending") throw new Error("รายการนี้ถูกดำเนินการแล้ว");
        await db.updateTopupStatus(input.topupId, "approved", input.adminNote);
        const user = await db.getAppUserById(topup.userId);
        if (user) {
          await db.updateAppUserCoins(topup.userId, user.coins + topup.coinsToAdd);
        }
        return { success: true };
      }),

    reject: publicProcedure
      .input(
        z.object({
          topupId: z.number(),
          adminId: z.number(),
          adminNote: z.string().optional(),
        }),
      )
      .mutation(async ({ input }) => {
        const admin = await db.getAppUserById(input.adminId);
        if (!admin || admin.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        await db.updateTopupStatus(input.topupId, "rejected", input.adminNote);
        return { success: true };
      }),
  }),

  // ===== Bank QR Codes =====
  bankQr: router({
    listActive: publicProcedure.query(async () => {
      return db.getActiveBankQrCodes();
    }),

    listAll: publicProcedure.query(async () => {
      return db.getAllBankQrCodes();
    }),

    create: publicProcedure
      .input(
        z.object({
          adminId: z.number(),
          bankName: z.string().min(1),
          accountName: z.string().min(1),
          accountNumber: z.string().optional(),
          qrImageBase64: z.string(),
          mimeType: z.string().default("image/png"),
        }),
      )
      .mutation(async ({ input }) => {
        const admin = await db.getAppUserById(input.adminId);
        if (!admin || admin.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        const buffer = Buffer.from(input.qrImageBase64, "base64");
        const ext = input.mimeType.split("/")[1] || "png";
        const fileName = `qr_${Date.now()}.${ext}`;
        const qrImageUrl = await uploadFile(buffer, fileName, input.mimeType);
        const id = await db.createBankQrCode({
          bankName: input.bankName,
          accountName: input.accountName,
          accountNumber: input.accountNumber,
          qrImageUrl,
          isActive: true,
        });
        return { id, qrImageUrl };
      }),

    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          adminId: z.number(),
          bankName: z.string().optional(),
          accountName: z.string().optional(),
          accountNumber: z.string().optional(),
          isActive: z.boolean().optional(),
        }),
      )
      .mutation(async ({ input }) => {
        const admin = await db.getAppUserById(input.adminId);
        if (!admin || admin.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        const { id, adminId, ...data } = input;
        await db.updateBankQrCode(id, data);
        return { success: true };
      }),

    delete: publicProcedure
      .input(z.object({ id: z.number(), adminId: z.number() }))
      .mutation(async ({ input }) => {
        const admin = await db.getAppUserById(input.adminId);
        if (!admin || admin.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        await db.deleteBankQrCode(input.id);
        return { success: true };
      }),
  }),

  // ===== File Upload =====
  upload: router({
    getUploadUrl: publicProcedure
      .input(
        z.object({
          userId: z.number(),
          fileName: z.string(),
          mimeType: z.string(),
          fileBase64: z.string(),
        }),
      )
      .mutation(async ({ input }) => {
        const user = await db.getAppUserById(input.userId);
        if (!user || user.role !== "admin") throw new Error("ไม่มีสิทธิ์อัพโหลดไฟล์");
        const buffer = Buffer.from(input.fileBase64, "base64");
        const url = await uploadFile(buffer, input.fileName, input.mimeType);
        return { url };
      }),
  }),

  // ===== Admin Stats =====
  admin: router({
    stats: publicProcedure
      .input(z.object({ adminId: z.number() }))
      .query(async ({ input }) => {
        const admin = await db.getAppUserById(input.adminId);
        if (!admin || admin.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        const [allUsers, allProducts, allOrders, allTopups] = await Promise.all([
          db.getAllAppUsers(),
          db.getAllProducts(),
          db.getAllOrders(),
          db.getAllTopups(),
        ]);
        const approvedTopups = allTopups.filter((t) => t.status === "approved");
        const totalRevenue = approvedTopups.reduce((sum, t) => sum + t.coinsToAdd, 0);
        return {
          totalUsers: allUsers.length,
          totalProducts: allProducts.length,
          totalOrders: allOrders.length,
          pendingTopups: allTopups.filter((t) => t.status === "pending").length,
          totalRevenue,
        };
      }),

    users: publicProcedure
      .input(z.object({ adminId: z.number() }))
      .query(async ({ input }) => {
        const admin = await db.getAppUserById(input.adminId);
        if (!admin || admin.role !== "admin") throw new Error("ไม่มีสิทธิ์");
        return db.getAllAppUsers();
      }),
  }),
});

export type AppRouter = typeof appRouter;
