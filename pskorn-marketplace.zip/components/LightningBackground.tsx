import React, { useEffect, useRef } from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withDelay,
  withSequence,
  Easing,
} from "react-native-reanimated";
import Svg, { Path, G } from "react-native-svg";

const { width, height } = Dimensions.get("window");

type LightningBoltProps = {
  x: number;
  y: number;
  size: number;
  delay: number;
  duration: number;
  color: string;
};

function LightningBolt({ x, y, size, delay, duration, color }: LightningBoltProps) {
  const opacity = useSharedValue(0);
  const translateY = useSharedValue(0);
  const rotate = useSharedValue(0);

  useEffect(() => {
    opacity.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(0.8, { duration: 300, easing: Easing.out(Easing.quad) }),
          withTiming(0.2, { duration: duration, easing: Easing.inOut(Easing.quad) }),
          withTiming(0.9, { duration: 200, easing: Easing.out(Easing.quad) }),
          withTiming(0, { duration: 400, easing: Easing.in(Easing.quad) }),
        ),
        -1,
        false,
      ),
    );
    translateY.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(-20, { duration: duration + 500, easing: Easing.inOut(Easing.sin) }),
          withTiming(20, { duration: duration + 500, easing: Easing.inOut(Easing.sin) }),
        ),
        -1,
        true,
      ),
    );
    rotate.value = withDelay(
      delay,
      withRepeat(
        withSequence(
          withTiming(-15, { duration: duration * 2, easing: Easing.inOut(Easing.sin) }),
          withTiming(15, { duration: duration * 2, easing: Easing.inOut(Easing.sin) }),
        ),
        -1,
        true,
      ),
    );
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [
      { translateY: translateY.value },
      { rotate: `${rotate.value}deg` },
    ],
  }));

  return (
    <Animated.View style={[{ position: "absolute", left: x, top: y }, animStyle]}>
      <Svg width={size} height={size * 1.8} viewBox="0 0 24 44">
        <Path
          d="M13 2L4 22H11L9 42L20 18H13L16 2Z"
          fill={color}
          opacity={0.9}
        />
      </Svg>
    </Animated.View>
  );
}

const BOLTS = [
  { x: width * 0.05, y: height * 0.1, size: 18, delay: 0, duration: 2000, color: "#FFD700" },
  { x: width * 0.8, y: height * 0.05, size: 24, delay: 500, duration: 2500, color: "#FFEC00" },
  { x: width * 0.15, y: height * 0.5, size: 14, delay: 1000, duration: 1800, color: "#FFC200" },
  { x: width * 0.7, y: height * 0.35, size: 20, delay: 1500, duration: 2200, color: "#FFD700" },
  { x: width * 0.4, y: height * 0.15, size: 16, delay: 800, duration: 2100, color: "#FFEC00" },
  { x: width * 0.9, y: height * 0.65, size: 22, delay: 300, duration: 1900, color: "#FFD700" },
  { x: width * 0.25, y: height * 0.75, size: 12, delay: 1200, duration: 2300, color: "#FFC200" },
  { x: width * 0.6, y: height * 0.8, size: 18, delay: 700, duration: 2000, color: "#FFEC00" },
  { x: width * 0.5, y: height * 0.45, size: 10, delay: 1800, duration: 1700, color: "#FFD700" },
  { x: width * 0.03, y: height * 0.85, size: 16, delay: 400, duration: 2400, color: "#FFC200" },
];

export function LightningBackground() {
  return (
    <View style={StyleSheet.absoluteFillObject} pointerEvents="none">
      {BOLTS.map((bolt, i) => (
        <LightningBolt key={i} {...bolt} />
      ))}
    </View>
  );
}
